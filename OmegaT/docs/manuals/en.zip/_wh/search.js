function Snowball() {
BaseStemmer = function() {
this.setCurrent = function(value) {
this.current = value;
this.cursor = 0;
this.limit = this.current.length;
this.limit_backward = 0;
this.bra = this.cursor;
this.ket = this.limit;
};
this.getCurrent = function() {
return this.current;
};
this.copy_from = function(other) {
this.current = other.current;
this.cursor = other.cursor;
this.limit = other.limit;
this.limit_backward = other.limit_backward;
this.bra = other.bra;
this.ket = other.ket;
};
this.in_grouping = function(s, min, max) {
if (this.cursor >= this.limit) return false;
var ch = this.current.charCodeAt(this.cursor);
if (ch > max || ch < min) return false;
ch -= min;
if ((s[ch >>> 3] & (0x1 << (ch & 0x7))) == 0) return false;
this.cursor++;
return true;
};
this.in_grouping_b = function(s, min, max) {
if (this.cursor <= this.limit_backward) return false;
var ch = this.current.charCodeAt(this.cursor - 1);
if (ch > max || ch < min) return false;
ch -= min;
if ((s[ch >>> 3] & (0x1 << (ch & 0x7))) == 0) return false;
this.cursor--;
return true;
};
this.out_grouping = function(s, min, max) {
if (this.cursor >= this.limit) return false;
var ch = this.current.charCodeAt(this.cursor);
if (ch > max || ch < min) {
this.cursor++;
return true;
}
ch -= min;
if ((s[ch >>> 3] & (0X1 << (ch & 0x7))) == 0) {
this.cursor++;
return true;
}
return false;
};
this.out_grouping_b = function(s, min, max) {
if (this.cursor <= this.limit_backward) return false;
var ch = this.current.charCodeAt(this.cursor - 1);
if (ch > max || ch < min) {
this.cursor--;
return true;
}
ch -= min;
if ((s[ch >>> 3] & (0x1 << (ch & 0x7))) == 0) {
this.cursor--;
return true;
}
return false;
};
this.eq_s = function(s)
{
if (this.limit - this.cursor < s.length) return false;
if (this.current.slice(this.cursor, this.cursor + s.length) != s)
{
return false;
}
this.cursor += s.length;
return true;
};
this.eq_s_b = function(s)
{
if (this.cursor - this.limit_backward < s.length) return false;
if (this.current.slice(this.cursor - s.length, this.cursor) != s)
{
return false;
}
this.cursor -= s.length;
return true;
};
 this.find_among = function(v)
{
var i = 0;
var j = v.length;
var c = this.cursor;
var l = this.limit;
var common_i = 0;
var common_j = 0;
var first_key_inspected = false;
while (true)
{
var k = i + ((j - i) >>> 1);
var diff = 0;
var common = common_i < common_j ? common_i : common_j; 
var w = v[k];
var i2;
for (i2 = common; i2 < w[0].length; i2++)
{
if (c + common == l)
{
diff = -1;
break;
}
diff = this.current.charCodeAt(c + common) - w[0].charCodeAt(i2);
if (diff != 0) break;
common++;
}
if (diff < 0)
{
j = k;
common_j = common;
}
else
{
i = k;
common_i = common;
}
if (j - i <= 1)
{
if (i > 0) break; 
if (j == i) break; 
if (first_key_inspected) break;
first_key_inspected = true;
}
}
do {
var w = v[i];
if (common_i >= w[0].length)
{
this.cursor = c + w[0].length;
if (w.length < 4) return w[2];
var res = w[3](this);
this.cursor = c + w[0].length;
if (res) return w[2];
}
i = w[1];
} while (i >= 0);
return 0;
};
this.find_among_b = function(v)
{
var i = 0;
var j = v.length
var c = this.cursor;
var lb = this.limit_backward;
var common_i = 0;
var common_j = 0;
var first_key_inspected = false;
while (true)
{
var k = i + ((j - i) >> 1);
var diff = 0;
var common = common_i < common_j ? common_i : common_j;
var w = v[k];
var i2;
for (i2 = w[0].length - 1 - common; i2 >= 0; i2--)
{
if (c - common == lb)
{
diff = -1;
break;
}
diff = this.current.charCodeAt(c - 1 - common) - w[0].charCodeAt(i2);
if (diff != 0) break;
common++;
}
if (diff < 0)
{
j = k;
common_j = common;
}
else
{
i = k;
common_i = common;
}
if (j - i <= 1)
{
if (i > 0) break;
if (j == i) break;
if (first_key_inspected) break;
first_key_inspected = true;
}
}
do {
var w = v[i];
if (common_i >= w[0].length)
{
this.cursor = c - w[0].length;
if (w.length < 4) return w[2];
var res = w[3](this);
this.cursor = c - w[0].length;
if (res) return w[2];
}
i = w[1];
} while (i >= 0);
return 0;
};
this.replace_s = function(c_bra, c_ket, s)
{
var adjustment = s.length - (c_ket - c_bra);
this.current = this.current.slice(0, c_bra) + s + this.current.slice(c_ket);
this.limit += adjustment;
if (this.cursor >= c_ket) this.cursor += adjustment;
else if (this.cursor > c_bra) this.cursor = c_bra;
return adjustment;
};
this.slice_check = function()
{
if (this.bra < 0 ||
this.bra > this.ket ||
this.ket > this.limit ||
this.limit > this.current.length)
{
return false;
}
return true;
};
this.slice_from = function(s)
{
var result = false;
if (this.slice_check())
{
this.replace_s(this.bra, this.ket, s);
result = true;
}
return result;
};
this.slice_del = function()
{
return this.slice_from("");
};
this.insert = function(c_bra, c_ket, s)
{
var adjustment = this.replace_s(c_bra, c_ket, s);
if (c_bra <= this.bra) this.bra += adjustment;
if (c_bra <= this.ket) this.ket += adjustment;
};
this.slice_to = function()
{
var result = '';
if (this.slice_check())
{
result = this.current.slice(this.bra, this.ket);
}
return result;
};
this.assign_to = function()
{
return this.current.slice(0, this.limit);
};
};
EnglishStemmer = function() {
var base = new BaseStemmer();
 var a_0 = [
["arsen", -1, -1],
["commun", -1, -1],
["gener", -1, -1]
];
 var a_1 = [
["'", -1, 1],
["'s'", 0, 1],
["'s", -1, 1]
];
 var a_2 = [
["ied", -1, 2],
["s", -1, 3],
["ies", 1, 2],
["sses", 1, 1],
["ss", 1, -1],
["us", 1, -1]
];
 var a_3 = [
["", -1, 3],
["bb", 0, 2],
["dd", 0, 2],
["ff", 0, 2],
["gg", 0, 2],
["bl", 0, 1],
["mm", 0, 2],
["nn", 0, 2],
["pp", 0, 2],
["rr", 0, 2],
["at", 0, 1],
["tt", 0, 2],
["iz", 0, 1]
];
 var a_4 = [
["ed", -1, 2],
["eed", 0, 1],
["ing", -1, 2],
["edly", -1, 2],
["eedly", 3, 1],
["ingly", -1, 2]
];
 var a_5 = [
["anci", -1, 3],
["enci", -1, 2],
["ogi", -1, 13],
["li", -1, 15],
["bli", 3, 12],
["abli", 4, 4],
["alli", 3, 8],
["fulli", 3, 9],
["lessli", 3, 14],
["ousli", 3, 10],
["entli", 3, 5],
["aliti", -1, 8],
["biliti", -1, 12],
["iviti", -1, 11],
["tional", -1, 1],
["ational", 14, 7],
["alism", -1, 8],
["ation", -1, 7],
["ization", 17, 6],
["izer", -1, 6],
["ator", -1, 7],
["iveness", -1, 11],
["fulness", -1, 9],
["ousness", -1, 10]
];
 var a_6 = [
["icate", -1, 4],
["ative", -1, 6],
["alize", -1, 3],
["iciti", -1, 4],
["ical", -1, 4],
["tional", -1, 1],
["ational", 5, 2],
["ful", -1, 5],
["ness", -1, 5]
];
 var a_7 = [
["ic", -1, 1],
["ance", -1, 1],
["ence", -1, 1],
["able", -1, 1],
["ible", -1, 1],
["ate", -1, 1],
["ive", -1, 1],
["ize", -1, 1],
["iti", -1, 1],
["al", -1, 1],
["ism", -1, 1],
["ion", -1, 2],
["er", -1, 1],
["ous", -1, 1],
["ant", -1, 1],
["ent", -1, 1],
["ment", 15, 1],
["ement", 16, 1]
];
 var a_8 = [
["e", -1, 1],
["l", -1, 2]
];
 var a_9 = [
["succeed", -1, -1],
["proceed", -1, -1],
["exceed", -1, -1],
["canning", -1, -1],
["inning", -1, -1],
["earring", -1, -1],
["herring", -1, -1],
["outing", -1, -1]
];
 var a_10 = [
["andes", -1, -1],
["atlas", -1, -1],
["bias", -1, -1],
["cosmos", -1, -1],
["dying", -1, 3],
["early", -1, 9],
["gently", -1, 7],
["howe", -1, -1],
["idly", -1, 6],
["lying", -1, 4],
["news", -1, -1],
["only", -1, 10],
["singly", -1, 11],
["skies", -1, 2],
["skis", -1, 1],
["sky", -1, -1],
["tying", -1, 5],
["ugly", -1, 8]
];
 var  g_v = [17, 65, 16, 1];
 var  g_v_WXY = [1, 17, 65, 208, 1];
 var  g_valid_LI = [55, 141, 2];
var  B_Y_found = false;
var  I_p2 = 0;
var  I_p1 = 0;
function r_prelude() {
B_Y_found = false;
var  v_1 = base.cursor;
lab0: {
base.bra = base.cursor;
if (!(base.eq_s("'")))
{
break lab0;
}
base.ket = base.cursor;
if (!base.slice_del())
{
return false;
}
}
base.cursor = v_1;
var  v_2 = base.cursor;
lab1: {
base.bra = base.cursor;
if (!(base.eq_s("y")))
{
break lab1;
}
base.ket = base.cursor;
if (!base.slice_from("Y"))
{
return false;
}
B_Y_found = true;
}
base.cursor = v_2;
var  v_3 = base.cursor;
lab2: {
while(true)
{
var  v_4 = base.cursor;
lab3: {
golab4: while(true)
{
var  v_5 = base.cursor;
lab5: {
if (!(base.in_grouping(g_v, 97, 121)))
{
break lab5;
}
base.bra = base.cursor;
if (!(base.eq_s("y")))
{
break lab5;
}
base.ket = base.cursor;
base.cursor = v_5;
break golab4;
}
base.cursor = v_5;
if (base.cursor >= base.limit)
{
break lab3;
}
base.cursor++;
}
if (!base.slice_from("Y"))
{
return false;
}
B_Y_found = true;
continue;
}
base.cursor = v_4;
break;
}
}
base.cursor = v_3;
return true;
};
function r_mark_regions() {
I_p1 = base.limit;
I_p2 = base.limit;
var  v_1 = base.cursor;
lab0: {
lab1: {
var  v_2 = base.cursor;
lab2: {
if (base.find_among(a_0) == 0)
{
break lab2;
}
break lab1;
}
base.cursor = v_2;
golab3: while(true)
{
lab4: {
if (!(base.in_grouping(g_v, 97, 121)))
{
break lab4;
}
break golab3;
}
if (base.cursor >= base.limit)
{
break lab0;
}
base.cursor++;
}
golab5: while(true)
{
lab6: {
if (!(base.out_grouping(g_v, 97, 121)))
{
break lab6;
}
break golab5;
}
if (base.cursor >= base.limit)
{
break lab0;
}
base.cursor++;
}
}
I_p1 = base.cursor;
golab7: while(true)
{
lab8: {
if (!(base.in_grouping(g_v, 97, 121)))
{
break lab8;
}
break golab7;
}
if (base.cursor >= base.limit)
{
break lab0;
}
base.cursor++;
}
golab9: while(true)
{
lab10: {
if (!(base.out_grouping(g_v, 97, 121)))
{
break lab10;
}
break golab9;
}
if (base.cursor >= base.limit)
{
break lab0;
}
base.cursor++;
}
I_p2 = base.cursor;
}
base.cursor = v_1;
return true;
};
function r_shortv() {
lab0: {
var  v_1 = base.limit - base.cursor;
lab1: {
if (!(base.out_grouping_b(g_v_WXY, 89, 121)))
{
break lab1;
}
if (!(base.in_grouping_b(g_v, 97, 121)))
{
break lab1;
}
if (!(base.out_grouping_b(g_v, 97, 121)))
{
break lab1;
}
break lab0;
}
base.cursor = base.limit - v_1;
if (!(base.out_grouping_b(g_v, 97, 121)))
{
return false;
}
if (!(base.in_grouping_b(g_v, 97, 121)))
{
return false;
}
if (base.cursor > base.limit_backward)
{
return false;
}
}
return true;
};
function r_R1() {
if (!(I_p1 <= base.cursor))
{
return false;
}
return true;
};
function r_R2() {
if (!(I_p2 <= base.cursor))
{
return false;
}
return true;
};
function r_Step_1a() {
var  among_var;
var  v_1 = base.limit - base.cursor;
lab0: {
base.ket = base.cursor;
if (base.find_among_b(a_1) == 0)
{
base.cursor = base.limit - v_1;
break lab0;
}
base.bra = base.cursor;
if (!base.slice_del())
{
return false;
}
}
base.ket = base.cursor;
among_var = base.find_among_b(a_2);
if (among_var == 0)
{
return false;
}
base.bra = base.cursor;
switch (among_var) {
case 1:
if (!base.slice_from("ss"))
{
return false;
}
break;
case 2:
lab1: {
var  v_2 = base.limit - base.cursor;
lab2: {
{
var  c1 = base.cursor - 2;
if (c1 < base.limit_backward)
{
break lab2;
}
base.cursor = c1;
}
if (!base.slice_from("i"))
{
return false;
}
break lab1;
}
base.cursor = base.limit - v_2;
if (!base.slice_from("ie"))
{
return false;
}
}
break;
case 3:
if (base.cursor <= base.limit_backward)
{
return false;
}
base.cursor--;
golab3: while(true)
{
lab4: {
if (!(base.in_grouping_b(g_v, 97, 121)))
{
break lab4;
}
break golab3;
}
if (base.cursor <= base.limit_backward)
{
return false;
}
base.cursor--;
}
if (!base.slice_del())
{
return false;
}
break;
}
return true;
};
function r_Step_1b() {
var  among_var;
base.ket = base.cursor;
among_var = base.find_among_b(a_4);
if (among_var == 0)
{
return false;
}
base.bra = base.cursor;
switch (among_var) {
case 1:
if (!r_R1())
{
return false;
}
if (!base.slice_from("ee"))
{
return false;
}
break;
case 2:
var  v_1 = base.limit - base.cursor;
golab0: while(true)
{
lab1: {
if (!(base.in_grouping_b(g_v, 97, 121)))
{
break lab1;
}
break golab0;
}
if (base.cursor <= base.limit_backward)
{
return false;
}
base.cursor--;
}
base.cursor = base.limit - v_1;
if (!base.slice_del())
{
return false;
}
var  v_3 = base.limit - base.cursor;
among_var = base.find_among_b(a_3);
if (among_var == 0)
{
return false;
}
base.cursor = base.limit - v_3;
switch (among_var) {
case 1:
{
var  c1 = base.cursor;
base.insert(base.cursor, base.cursor, "e");
base.cursor = c1;
}
break;
case 2:
base.ket = base.cursor;
if (base.cursor <= base.limit_backward)
{
return false;
}
base.cursor--;
base.bra = base.cursor;
if (!base.slice_del())
{
return false;
}
break;
case 3:
if (base.cursor != I_p1)
{
return false;
}
var  v_4 = base.limit - base.cursor;
if (!r_shortv())
{
return false;
}
base.cursor = base.limit - v_4;
{
var  c2 = base.cursor;
base.insert(base.cursor, base.cursor, "e");
base.cursor = c2;
}
break;
}
break;
}
return true;
};
function r_Step_1c() {
base.ket = base.cursor;
lab0: {
var  v_1 = base.limit - base.cursor;
lab1: {
if (!(base.eq_s_b("y")))
{
break lab1;
}
break lab0;
}
base.cursor = base.limit - v_1;
if (!(base.eq_s_b("Y")))
{
return false;
}
}
base.bra = base.cursor;
if (!(base.out_grouping_b(g_v, 97, 121)))
{
return false;
}
lab2: {
if (base.cursor > base.limit_backward)
{
break lab2;
}
return false;
}
if (!base.slice_from("i"))
{
return false;
}
return true;
};
function r_Step_2() {
var  among_var;
base.ket = base.cursor;
among_var = base.find_among_b(a_5);
if (among_var == 0)
{
return false;
}
base.bra = base.cursor;
if (!r_R1())
{
return false;
}
switch (among_var) {
case 1:
if (!base.slice_from("tion"))
{
return false;
}
break;
case 2:
if (!base.slice_from("ence"))
{
return false;
}
break;
case 3:
if (!base.slice_from("ance"))
{
return false;
}
break;
case 4:
if (!base.slice_from("able"))
{
return false;
}
break;
case 5:
if (!base.slice_from("ent"))
{
return false;
}
break;
case 6:
if (!base.slice_from("ize"))
{
return false;
}
break;
case 7:
if (!base.slice_from("ate"))
{
return false;
}
break;
case 8:
if (!base.slice_from("al"))
{
return false;
}
break;
case 9:
if (!base.slice_from("ful"))
{
return false;
}
break;
case 10:
if (!base.slice_from("ous"))
{
return false;
}
break;
case 11:
if (!base.slice_from("ive"))
{
return false;
}
break;
case 12:
if (!base.slice_from("ble"))
{
return false;
}
break;
case 13:
if (!(base.eq_s_b("l")))
{
return false;
}
if (!base.slice_from("og"))
{
return false;
}
break;
case 14:
if (!base.slice_from("less"))
{
return false;
}
break;
case 15:
if (!(base.in_grouping_b(g_valid_LI, 99, 116)))
{
return false;
}
if (!base.slice_del())
{
return false;
}
break;
}
return true;
};
function r_Step_3() {
var  among_var;
base.ket = base.cursor;
among_var = base.find_among_b(a_6);
if (among_var == 0)
{
return false;
}
base.bra = base.cursor;
if (!r_R1())
{
return false;
}
switch (among_var) {
case 1:
if (!base.slice_from("tion"))
{
return false;
}
break;
case 2:
if (!base.slice_from("ate"))
{
return false;
}
break;
case 3:
if (!base.slice_from("al"))
{
return false;
}
break;
case 4:
if (!base.slice_from("ic"))
{
return false;
}
break;
case 5:
if (!base.slice_del())
{
return false;
}
break;
case 6:
if (!r_R2())
{
return false;
}
if (!base.slice_del())
{
return false;
}
break;
}
return true;
};
function r_Step_4() {
var  among_var;
base.ket = base.cursor;
among_var = base.find_among_b(a_7);
if (among_var == 0)
{
return false;
}
base.bra = base.cursor;
if (!r_R2())
{
return false;
}
switch (among_var) {
case 1:
if (!base.slice_del())
{
return false;
}
break;
case 2:
lab0: {
var  v_1 = base.limit - base.cursor;
lab1: {
if (!(base.eq_s_b("s")))
{
break lab1;
}
break lab0;
}
base.cursor = base.limit - v_1;
if (!(base.eq_s_b("t")))
{
return false;
}
}
if (!base.slice_del())
{
return false;
}
break;
}
return true;
};
function r_Step_5() {
var  among_var;
base.ket = base.cursor;
among_var = base.find_among_b(a_8);
if (among_var == 0)
{
return false;
}
base.bra = base.cursor;
switch (among_var) {
case 1:
lab0: {
var  v_1 = base.limit - base.cursor;
lab1: {
if (!r_R2())
{
break lab1;
}
break lab0;
}
base.cursor = base.limit - v_1;
if (!r_R1())
{
return false;
}
{
var  v_2 = base.limit - base.cursor;
lab2: {
if (!r_shortv())
{
break lab2;
}
return false;
}
base.cursor = base.limit - v_2;
}
}
if (!base.slice_del())
{
return false;
}
break;
case 2:
if (!r_R2())
{
return false;
}
if (!(base.eq_s_b("l")))
{
return false;
}
if (!base.slice_del())
{
return false;
}
break;
}
return true;
};
function r_exception2() {
base.ket = base.cursor;
if (base.find_among_b(a_9) == 0)
{
return false;
}
base.bra = base.cursor;
if (base.cursor > base.limit_backward)
{
return false;
}
return true;
};
function r_exception1() {
var  among_var;
base.bra = base.cursor;
among_var = base.find_among(a_10);
if (among_var == 0)
{
return false;
}
base.ket = base.cursor;
if (base.cursor < base.limit)
{
return false;
}
switch (among_var) {
case 1:
if (!base.slice_from("ski"))
{
return false;
}
break;
case 2:
if (!base.slice_from("sky"))
{
return false;
}
break;
case 3:
if (!base.slice_from("die"))
{
return false;
}
break;
case 4:
if (!base.slice_from("lie"))
{
return false;
}
break;
case 5:
if (!base.slice_from("tie"))
{
return false;
}
break;
case 6:
if (!base.slice_from("idl"))
{
return false;
}
break;
case 7:
if (!base.slice_from("gentl"))
{
return false;
}
break;
case 8:
if (!base.slice_from("ugli"))
{
return false;
}
break;
case 9:
if (!base.slice_from("earli"))
{
return false;
}
break;
case 10:
if (!base.slice_from("onli"))
{
return false;
}
break;
case 11:
if (!base.slice_from("singl"))
{
return false;
}
break;
}
return true;
};
function r_postlude() {
if (!B_Y_found)
{
return false;
}
while(true)
{
var  v_1 = base.cursor;
lab0: {
golab1: while(true)
{
var  v_2 = base.cursor;
lab2: {
base.bra = base.cursor;
if (!(base.eq_s("Y")))
{
break lab2;
}
base.ket = base.cursor;
base.cursor = v_2;
break golab1;
}
base.cursor = v_2;
if (base.cursor >= base.limit)
{
break lab0;
}
base.cursor++;
}
if (!base.slice_from("y"))
{
return false;
}
continue;
}
base.cursor = v_1;
break;
}
return true;
};
this.stem =  function() {
lab0: {
var  v_1 = base.cursor;
lab1: {
if (!r_exception1())
{
break lab1;
}
break lab0;
}
base.cursor = v_1;
lab2: {
{
var  v_2 = base.cursor;
lab3: {
{
var  c1 = base.cursor + 3;
if (c1 > base.limit)
{
break lab3;
}
base.cursor = c1;
}
break lab2;
}
base.cursor = v_2;
}
break lab0;
}
base.cursor = v_1;
r_prelude();
r_mark_regions();
base.limit_backward = base.cursor; base.cursor = base.limit;
var  v_5 = base.limit - base.cursor;
r_Step_1a();
base.cursor = base.limit - v_5;
lab4: {
var  v_6 = base.limit - base.cursor;
lab5: {
if (!r_exception2())
{
break lab5;
}
break lab4;
}
base.cursor = base.limit - v_6;
var  v_7 = base.limit - base.cursor;
r_Step_1b();
base.cursor = base.limit - v_7;
var  v_8 = base.limit - base.cursor;
r_Step_1c();
base.cursor = base.limit - v_8;
var  v_9 = base.limit - base.cursor;
r_Step_2();
base.cursor = base.limit - v_9;
var  v_10 = base.limit - base.cursor;
r_Step_3();
base.cursor = base.limit - v_10;
var  v_11 = base.limit - base.cursor;
r_Step_4();
base.cursor = base.limit - v_11;
var  v_12 = base.limit - base.cursor;
r_Step_5();
base.cursor = base.limit - v_12;
}
base.cursor = base.limit_backward;
var  v_13 = base.cursor;
r_postlude();
base.cursor = v_13;
}
return true;
};
this['stemWord'] = function(word) {
base.setCurrent(word);
this.stem();
return base.getCurrent();
};
};
return new EnglishStemmer();
}
wh.search_stemmer = Snowball();
wh.search_baseNameList = [
 "index.html",
 "chapter.appendices.html",
 "chapter.how.to.html",
 "chapter.dialogs.preferences.html",
 "chapter.project.folder.html",
 "chapter.windows.and.dialogs.html",
 "chapter.menus.html",
 "chapter.panes.html",
 "chapter.instant.start.guide.html"
];
wh.search_titleList = [
 "OmegaT 6.1.0 - User Manual",
 "Chapter 8. Appendices",
 "Chapter 2. How To...",
 "Chapter 6. Preferences",
 "Chapter 7. Project Folder",
 "Chapter 5. Windows and Dialogs",
 "Chapter 4. Menus",
 "Chapter 3. Panes",
 "Chapter 1. Introduction to OmegaT"
];
wh.search_wordMap= {
"cancel": [1,6,5],
"altgraph": [1],
"stats-typ": [2],
"half": [3],
"upload": [2,6],
"don\'t": [4],
"your": [2,8,1,5,3,6,7,[0,4]],
"without": [2,5,1,3,4,7],
"these": [[1,5],4,2,8],
"would": [[1,4],[2,5]],
"xml": [1,2,3],
"ten": [[2,5],6],
"sake": [2],
"info.plist": [2],
"i.e": [1],
"sometim": [1,2],
"serv": [2],
"thus": [[2,3,8]],
"neutral": [1],
"noun": [7],
"scratch": [2],
"click": [5,[3,7,8],[1,6],2],
"fuzzi": [3,6,7,2,5,8,4,1,0],
"insensit": [1,5],
"xdg-open": [1],
"befor": [2,1,3,5,[4,6,8],7],
"util": [2],
"size": [3,5,2],
"left": [1,7,[5,6,8]],
"seri": [1],
"tar.bz": [4],
"much": [[2,3,8]],
"object": [5,[1,2]],
"arab": [1],
"chapter": [2,5,8,[1,6,7],[3,4],0],
"ahead": [1],
"yellow": [6],
"shebang": [1],
"turn": [1,2,[4,5,8]],
"suffici": [1],
"result": [5,1,2,[6,8],[3,7]],
"edittagnextmissedmenuitem": [1],
"same": [[2,5],1,3,8,7,6,4],
"editorskipprevtoken": [1],
"differenti": [6],
"checkbox": [5],
"after": [1,2,5,3,8,7,[4,6]],
"quiet": [2],
"flip": [1],
"connect": [[2,3],7],
"hand": [8],
"address": [1,2,[4,7]],
"gnu": [2,0],
"the": [1,2,5,6,3,7,8,4,0],
"wipe": [8],
"straight": [8],
"blue": [5,7],
"projectimportmenuitem": [1],
"obvious": [2],
"imag": [1],
"suzum": [3],
"monolingu": [[1,5]],
"target.txt": [[1,3]],
"goe": [5],
"demonstr": [1],
"temurin": [2],
"standard": [2,8,[1,3,5,6,7]],
"d\'espac": [2],
"correct": [5,[1,2,3,7],[4,6,8]],
"stdout": [1],
"traduct": [7],
"project-bas": [5],
"advic": [2],
"good": [[0,2],[3,8]],
"wish": [[0,5],[2,4]],
"omegat.project.lock": [2],
"nameon": [1],
"moodlephp": [2],
"currsegment.getsrctext": [5],
"implement": [3],
"alphanumer": [1],
"export": [1,[2,5,6],4,[0,3,8]],
"uncheck": [5,1,3],
"gotonextnotemenuitem": [1],
"area": [7,[2,5]],
"practic": [5,[1,2,4]],
"gpl": [1],
"newentri": [5],
"reduc": [5],
"check": [3,5,6,1,2,8,7],
"list": [1,3,2,5,8,6,7,4],
"onto": [2],
"autocompleterprevview": [1],
"rainbow-support": [2],
"resolut": [8],
"vowel": [1],
"gotonotespanelmenuitem": [1],
"fr-fr": [8,3],
"ascend": [1],
"ensur": [2,[1,5,8]],
"minim": [[0,2,3,4,7]],
"medium": [2],
"projectcommittargetfil": [1],
"pear": [1],
"determin": [3,5,1],
"root": [1,2],
"combin": [1,2,3,[4,5,6]],
"po4a": [2],
"japonai": [5],
"omegat.org": [2],
"menus": [[1,7],5,[2,4,6,8],0],
"hard": [2],
"realign": [5],
"object-ori": [5],
"cjk": [5,1],
"perform": [2,[5,8],[1,3]],
"prewritten": [4],
"alternatives—th": [7],
"maxprogram": [2],
"better": [[5,8],3],
"with": [1,2,5,3,6,8,7,4],
"pdf": [2,1,6,5],
"there": [2,5,1,6,7,[3,4,8]],
"syntax": [[1,2],5],
"well": [[1,2],5,[3,8],6,7],
"empti": [2,[4,6],[1,7],3,[5,8]],
"autocompletertabledown": [1],
"editornextsegmentnottab": [1],
"toolsshowstatisticsmatchesmenuitem": [1],
"channel": [1],
"focus": [8,2],
"viewdisplaymodificationinfononeradiobuttonmenuitem": [1],
"desir": [2,5,[3,7],1],
"approach": [2],
"variabl": [3,1,5],
"block": [5,1,6,[3,8]],
"tms": [2,6,[1,4,5,8],[0,3]],
"per": [4,[1,3,5,6,7]],
"write": [5,2,[6,7],[1,3]],
"flow": [1],
"tmx": [2,5,4,[3,7,8]],
"propos": [5],
"order": [3,[1,5],[4,6,7]],
"e.g": [[1,3],[2,5]],
"gtk": [3],
"project_save.tmx.bak": [[2,4]],
"repo_for_all_omegat_team_project": [2],
"cli": [2],
"period": [1,3,2],
"application_startup": [5],
"colleagu": [7],
"proceed": [2,[5,6]],
"eventtyp": [5],
"understand": [[1,2]],
"integ": [3],
"fr-ca": [3],
"mainmenushortcuts.properti": [1],
"ever": [[3,8]],
"projectaccesswriteableglossarymenuitem": [1],
"even": [2,[1,5],3,[6,8],[4,7]],
"aris": [2],
"application_shutdown": [5],
"autocompletertablelastinrow": [1],
"gui": [2,5,4],
"tmx-standard": [2],
"proport": [3],
"regexp": [1],
"subtitl": [2],
"sentencecasemenuitem": [1],
"gotohistorybackmenuitem": [1],
"save": [6,[2,5],3,[1,4],[0,7,8]],
"v1.0": [2],
"articl": [1],
"allowlist": [2],
"relaunch": [4],
"editorcontextmenu": [1],
"top": [7,3,5,[2,8]],
"too": [[2,3]],
"have": [2,1,5,8,3,6,4,7],
"powerpc": [2],
"mandatori": [1],
"optionssentsegmenuitem": [1],
"slowli": [2],
"avail": [5,2,1,3,7,6,8],
"product": [1],
"robust": [8,2],
"question": [1],
"bought": [1],
"hyphen": [1],
"optionsaccessconfigdirmenuitem": [1],
"editselectsourcemenuitem": [1],
"charact": [1,5,6,7,3,2,8,0],
"framework": [2],
"test.html": [2],
"php": [1],
"xxx": [4],
"instanc": [[1,2],[5,6],7],
"thousand": [1],
"smalltalk": [5],
"com": [1],
"instal": [2,3,[1,8],[0,4,5,6,7]],
"minor": [4],
"arrow": [5,7,[1,8]],
"almost": [[2,6]],
"cot": [1],
"remot": [2,4,6,[5,7]],
"manner": [8],
"upon": [[6,8],5],
"whenev": [[4,8]],
"lag": [2],
"earlier": [8],
"pseudotranslatetmx": [2],
"whether": [3,[1,7],5,[2,4]],
"unabl": [[3,7]],
"function": [1,6,8,5,[2,3],[4,7]],
"pipe": [1],
"start-up": [2],
"comparison": [5],
"targetlanguagecod": [1],
"undock": [7,3],
"revert": [1],
"tri": [5,2,3,1],
"editorprevsegmentnottab": [1],
"less": [2],
"changeid": [3],
"absolut": [[1,3]],
"translat": [2,5,8,1,7,6,3,4,0],
"eras": [[1,3]],
"uniqu": [5,[6,7],1],
"welcom": [8],
"bidirect": [6,1],
"were": [8,6,[2,7]],
"université": [3],
"basic": [2,5,1],
"disabl": [5,3,1,[6,7],2],
"footer": [1],
"cqt": [1],
"shorthand": [1],
"respons": [7],
"docs_devel": [2],
"lck": [7],
"twelv": [1],
"tsv": [1],
"extra": [[1,2,6,7]],
"design": [8,2],
"convey": [8],
"command-lin": [2],
"unpack": [2],
"semicolon": [2],
"gnome": [3],
"accord": [7,[2,3,5]],
"italian": [3],
"horizont": [1],
"doctor": [1],
"conduct": [5],
"projectnam": [1],
"omegat.project.yyyymmddhhmm.bak": [2],
"appdata": [1],
"gotten": [8],
"configdir": [2],
"prev": [[1,2,3,4,5,6,7,8]],
"csv": [1,2],
"installdist": [2],
"a-z": [1],
"enhanc": [6],
"password": [2,3],
"ambigu": [1],
"caractèr": [2],
"let": [5,[1,2,7,8]],
"state": [2,1,5,[4,8]],
"gotonextxenforcedmenuitem": [1],
"editordeleteprevtoken": [1],
"les": [7],
"press": [5,6,8,[1,7],3],
"eventu": [[2,8]],
"dock": [2,[7,8]],
"onlin": [[1,2]],
"coffe": [8],
"element": [1,[5,8]],
"caret": [1],
"want": [5,2,1,6,[3,4,8],7],
"processor": [5,8],
"each": [1,5,[2,3],6,7,8,4],
"javascript": [5],
"mediawiki": [[5,6],[1,8]],
"english-japanes": [2],
"input": [6,[2,3]],
"cue": [1],
"toolkit": [2],
"creativ": [1],
"must": [1,2,3,4],
"join.html": [1],
"suppli": [3],
"non-omegat": [3],
"cur": [1],
"filenameon": [3,1],
"cut": [1,7],
"ctrl": [1,6],
"editorinsertlinebreak": [1],
"jumptoentryineditor": [1],
"document": [1,2,5,8,[6,7],[0,3,4]],
"omegat.kaptn": [2],
"misplac": [6],
"multi-cel": [5],
"mainten": [2],
"two": [2,1,5,[3,6,7],[4,8]],
"accident": [3],
"user-defin": [5],
"pop": [1,6],
"page_up": [1],
"found": [5,6,2,[1,3],4,[7,8]],
"usernam": [2],
"glossaryroot": [1],
"scenario": [2],
"encrypt": [1],
"larg": [5,[2,8]],
"attach": [5,3],
"anoth": [2,[1,5,6]],
"freez": [2],
"advantag": [1],
"graphic": [2],
"creation": [6,[3,8]],
"resourc": [[5,8],4,2,1],
"latest": [4],
"pend": [5],
"moodl": [1],
"project.folder.omegat.ignored.word": [3],
"team": [2,6,[1,4],[0,5,8],3,7],
"xx_yy": [1],
"side-by-sid": [2],
"docx": [[2,5],[1,6]],
"project_stats_match_per_file.txt": [[4,6]],
"diagram": [1],
"txt": [2,1,7],
"googl": [3],
"quit": [6,[1,3]],
"re-ent": [3],
"chart": [1],
"thing": [[2,8]],
"gotoeditorpanelmenuitem": [1],
"fashion": [8],
"definit": [1,3],
"projectmedopenmenuitem": [1],
"lib": [1],
"viewmarkfontfallbackcheckboxmenuitem": [1],
"tedious": [8],
"had": [8,[1,5]],
"prepar": [1,2],
"align": [5,6,[1,2],8,[0,3]],
"adjac": [7],
"endnot": [1],
"insertcharsrlm": [1],
"redistribut": [0],
"sourceforg": [2,1],
"structur": [5,[1,4],2,[0,8]],
"han": [1],
"viewdisplaymodificationinfoselectedradiobuttonmenuitem": [1],
"entir": [1,[2,6,7,8]],
"index.html": [1,2],
"semeru-runtim": [2],
"has": [2,6,1,[5,7],3,[4,8]],
"keyword": [5,8],
"given": [2,[1,3],4],
"doubl": [1,2],
"actual": [8,[1,2]],
"unlock": [7,3,8],
"autosav": [7],
"last": [1,6,[3,5],7,2,[4,8]],
"editmultipledefault": [1],
"adapt": [[3,5],8],
"batch": [2],
"mozilla": [[1,2]],
"doubt": [[4,5]],
"editfindinprojectmenuitem": [1],
"develop": [2,[1,5]],
"reproduc": [[1,5]],
"diffrevers": [3],
"weak-direct": [1],
"warn": [5,2,3,1,8,6,4,7],
"bookmark": [1],
"easiest": [1,2],
"inlin": [5],
"page": [1,[5,6],[2,8],3],
"full": [1,[3,5],2,7],
"plural": [1],
"away": [[2,3,8]],
"becaus": [1,[2,3]],
"three-column": [1],
"parenthesi": [1],
"project.gettranslationinfo": [5],
"czt": [1],
"doctorat": [3],
"overview": [2],
"yes": [5],
"duckduckgo.com": [3],
"start": [1,5,8,2,[3,6,7]],
"yet": [3,[6,8],[2,4,5]],
"mymemori": [3],
"stylist": [1],
"generic": [3,[1,2]],
"pair": [1,[2,3],5],
"regex101": [1],
"equal": [1,[2,3,6,7]],
"colour": [3,6,[1,4,5]],
"chang": [5,[1,2,3],4,6,8,7,0],
"watson": [3],
"anywher": [[4,7],[1,5]],
"short": [5,8,[3,6]],
"pop-up": [7],
"time": [8,2,1,5,4,6,7,3],
"tmxs": [3],
"kanji": [1],
"program": [2,1,[5,8],[3,6,7]],
"three": [1,2,[3,4,6],[5,7,8]],
"cyan": [6],
"put": [2,1,4,3,8],
"python3": [1],
"project_save.tmx.yyyymmddhhmm.bak": [2],
"viewmarkglossarymatchescheckboxmenuitem": [1],
"enter": [5,[1,6],[3,8],7,2],
"prioriti": [[3,6],[2,8]],
"tran": [1],
"pale": [6],
"applic": [2,1,5,6,8,[3,4],[0,7]],
"bidi": [1,6,5],
"projectteamnewmenuitem": [1],
"gotoprevxenforcedmenuitem": [1],
"iraq": [1],
"dossier": [7],
"preced": [1,6,5,2],
"right-click": [5,[6,7],[2,4]],
"directorate-gener": [6],
"non-seg": [1],
"brunt": [1],
"memori": [2,5,8,4,7,6,1,3,0],
"autocompletertablelast": [1],
"authent": [2,3,7],
"no-match": [6],
"retransl": [2],
"indefinit": [1],
"quot": [1],
"recogn": [1,5,8,[2,3,4,7],6],
"tabl": [1,3,[6,7],0],
"post-process": [5,[1,3],0],
"engin": [7,[3,6],5],
"log": [1,6],
"four-step": [5],
"smart": [2],
"lot": [1,8],
"doc-license.txt": [1],
"openjdk": [3],
"永住権": [[3,5]],
"consult": [2,1],
"theme": [3,5],
"toolscheckissuesmenuitem": [1],
"チューリッヒ": [3],
"pane": [7,[5,8],6,3,4,[1,2],0],
"undesir": [6],
"meant": [4],
"editor": [5,1,7,8,3,6,4,[0,2]],
"pseudotranslatetyp": [2],
"chain": [1],
"tutori": [1],
"orphan": [[5,7]],
"cycl": [6,[1,7]],
"autocompletertablepageup": [1],
"fetch": [[3,6],1],
"char": [5],
"small": [6,1],
"config-fil": [2],
"quick": [5,[1,8],[2,6]],
"tell": [2,[1,5,8]],
"unavail": [1],
"projectclosemenuitem": [1],
"checker": [3,[1,6]],
"viewmarknonuniquesegmentscheckboxmenuitem": [1],
"hit": [5,6],
"shown": [7,5,[1,6],[2,3]],
"major": [1,2],
"titl": [6,[1,5]],
"consider": [2],
"inspir": [5],
"day": [[1,2],6],
"lre": [1,6],
"group": [1,3,[5,7],[2,8]],
"obtain": [5,[3,7,8]],
"suppos": [1],
"system-user-nam": [1],
"findinprojectreuselastwindow": [1],
"lrm": [1,6],
"liter": [1,3],
"format": [2,1,6,8,5,[3,7],4,0],
"tree": [4],
"particular": [2,5],
"readme.txt": [2,1],
"done": [2,8],
"languagetool": [6,[0,3,5]],
"console.println": [5],
"savour": [8],
"rainbow": [2],
"source.txt": [[1,3]],
"twice": [8],
"files.s": [5],
"autocompleterlistdown": [1],
"histori": [6,[1,3],8],
"exchang": [1],
"auto-sync": [5],
"achiev": [[1,2,5]],
"launcher": [2],
"request": [2],
"procedur": [2],
"pars": [[1,5,7]],
"part": [1,5,[3,6],[7,8],[2,4]],
"currseg": [5],
"their": [1,[2,5],8,3,[4,6,7]],
"generat": [[2,4],[1,3,6,8]],
"unexpect": [2],
"right-end": [7],
"point": [[1,2],3,5],
"general": [[1,5],2,3,7,0,8],
"browser": [3,[6,7]],
"activefilenam": [5],
"easi": [8,2],
"process": [8,2,[1,3,5],6,0],
"project_files_show_on_load": [1],
"autocompletertrigg": [1],
"instance—a": [7],
"attribut": [1],
"clear": [[5,6]],
"apostroph": [1],
"third": [[2,4,7],[1,3]],
"acquiert": [3],
"build": [2,5],
"mean": [1,2,[3,5,7]],
"neither": [[1,3]],
"further": [8,[1,4],[5,7]],
"account": [2,[3,6],[4,5]],
"snippet": [5],
"been": [2,6,5,[3,4,8],1],
"stack": [5],
"dhttp.proxyhost": [2],
"japanes": [2,3,1],
"ident": [6,5,2,[3,4],[1,7]],
"entries.s": [5],
"addit": [1,[2,5],3,[6,8]],
"alphabet": [1,[5,7]],
"simplifi": [[2,3]],
"gotonextuntranslatedmenuitem": [1],
"targetlocal": [1],
"systemwid": [2],
"editorprevseg": [1],
"path": [2,1,3,[5,7]],
"trip": [2],
"bind": [5],
"overwritten": [2,8,6,[1,3,5]],
"abbrevi": [1],
"record": [1,4],
"monospac": [3],
"a-za-z0": [1],
"strict": [2],
"you": [2,5,1,8,3,6,4,7,0],
"jump": [[5,7,8],[1,6]],
"reinsert": [8],
"happen": [2],
"www.apertium.org": [3],
"pass": [2,1],
"past": [6,[2,7]],
"impact": [8],
"mainstream": [1],
"especi": [[2,5]],
"percentag": [7,3,4],
"whose": [[2,6]],
"cours": [[4,5,6]],
"project_save.tmx.tmp": [2],
"configur": [2,1,3,[5,6],[7,8],0],
"nativ": [2,[1,3]],
"helpcontentsmenuitem": [1],
"finer": [3],
"resnam": [1],
"omegat-org": [2],
"descript": [6,[3,5],[1,8]],
"remote-project": [2],
"preserv": [1,2,3],
"initialcreationid": [3],
"ignore.txt": [4],
"organ": [1],
"mega": [1],
"projectaccessdictionarymenuitem": [1],
"zurich": [3],
"mirror": [5],
"空白文字": [2],
"sentenc": [1,[5,8],[2,3],6],
"alongsid": [2],
"optionsworkflowmenuitem": [1],
"consecut": [5,1],
"how": [8,1,[3,7],2,0,5],
"releas": [2,[1,6]],
"term": [5,7,[3,6],8,1,4,0],
"backslash": [1,2],
"files_order.txt": [4],
"mind": [[1,2,5]],
"projectrestartmenuitem": [1],
"editorskipnexttoken": [1],
"trans-unit": [1],
"right": [[1,7],5,2,8,[3,4,6]],
"opposit": [1],
"insid": [[1,2],7],
"qigong": [1],
"dictroot": [1],
"stage": [[2,5]],
"keybind": [5],
"maximum": [1,[2,5]],
"under": [2,[3,6],[0,1,4,5,7]],
"xhmtl": [1],
"submenus": [[2,5]],
"did": [5],
"represent": [5],
"imper": [5],
"reserv": [2],
"dir": [2],
"down": [1,5,6,[3,8]],
"hold": [5,8,7],
"linebreak": [1],
"trail": [1],
"subdir": [2],
"later": [2,8,[1,4,5],7],
"legal": [1],
"bracket": [1],
"unrespons": [5],
"viewfilelistmenuitem": [1],
"info": [1,[3,6,7]],
"brows": [5,7],
"hyperlink": [7],
"autocompletertableleft": [1],
"non-break": [5,1,6,[3,8]],
"journey": [1],
"test": [2,1],
"count": [6,3],
"omegat": [2,1,[5,8],3,6,4,7,0],
"forward-backward": [5],
"allemand": [3,5],
"take": [1,[2,5],[6,8],3],
"month": [[1,2],8],
"thereof": [[1,2]],
"final": [1,8,[2,4]],
"excerpt": [1],
"editorlastseg": [1],
"file-source-encod": [1],
"occasion": [8],
"some": [2,1,3,4,[5,6,7,8]],
"virtual": [5,2],
"blank": [1],
"rather": [1,5,[2,6,8]],
"session": [1,[2,5,7,8]],
"console-align": [[2,5]],
"dissimul": [7],
"back": [5,[7,8],2,1,6,4],
"projectopenrecentmenuitem": [1],
"fr_fr": [8],
"miss": [6,1,8,[2,7]],
"thèse": [3],
"load": [[2,5],3,[1,4]],
"alpha": [2],
"大学院博士課程修了": [3],
"just": [1,8,2,[4,5]],
"human": [3],
"divid": [1,5],
"primarili": [2],
"collabor": [[2,8]],
"custom": [1,[2,3],6,8,5],
"editexportselectionmenuitem": [1],
"length": [1,3],
"issue_provider_sample.groovi": [5],
"home": [1,2,[3,4,5,6,7,8]],
"disable-location-sav": [2],
"print": [[1,2,5]],
"condit": [2],
"glyph": [6],
"unl": [7],
"although": [[1,2],5],
"projectaccesstargetmenuitem": [1],
"interpret": [1],
"editoverwritemachinetranslationmenuitem": [1],
"iana": [1],
"relat": [2,[3,4],[1,7,8]],
"advantageous—even": [2],
"grant": [[0,2]],
"console-stat": [2],
"ingreek": [1],
"lunch": [1],
"f12": [5],
"visibl": [[1,4]],
"convers": [2,3],
"ignor": [1,4,[3,5,6,7],2],
"convert": [2,8,[1,3,5,6]],
"elsewher": [6],
"hope": [8],
"attempt": [2,5,[1,3]],
"assembl": [2,[3,5]],
"soon": [[4,5,6]],
"influenc": [6],
"projectexitmenuitem": [1],
"aligndir": [2],
"system-host-nam": [1],
"lock": [7,2,3,[1,8]],
"action": [5,2,[6,7],8,3],
"adoptium": [2],
"text": [1,5,[3,6],7,[2,8],4,0],
"latin": [1],
"mymemory.translated.net": [3],
"en-to-fr": [2],
"fear": [2],
"editregisteruntranslatedmenuitem": [1],
"creat": [2,5,1,8,6,4,7,3,0],
"init": [2],
"python": [5],
"misspel": [1],
"made": [2,[1,8],6,[3,4,5,7]],
"block-level": [1],
"manag": [2,6,8,0,[3,4,5]],
"manifest.mf": [2],
"maco": [1,2,6,7,8,3],
"field": [5,7,6,1,[2,8],3],
"tarbal": [4],
"singl": [1,5,8,3],
"invalid": [2],
"doc": [5,1],
"doe": [1,2,5,8,3,6,0],
"output-fil": [2],
"notifi": [7,3],
"status": [7,[1,2,4,8],[0,3,6]],
"server": [2,3,4,7],
"don": [8],
"dot": [1,6],
"paramet": [2,1,5,3,4],
"stamp": [[1,4]],
"deliver": [2],
"run-on": [1],
"skip": [1,4],
"overrid": [[1,2]],
"mac": [6],
"file": [2,1,5,6,4,8,3,7,0],
"known": [[1,6]],
"member": [2,8],
"map": [2,5,4],
"may": [2,1,5,7,[3,4,6,8]],
"within": [1,[4,7],8],
"forward": [[1,6]],
"could": [[1,2,4,5]],
"trigger": [5,[1,2]],
"menu": [1,6,7,3,[5,8],2,4],
"url": [2,3,[4,8],[1,5,6]],
"exercis": [2],
"megabyt": [2],
"system-wid": [1],
"uppercasemenuitem": [1],
"explan": [5,[1,3]],
"viewmarkuntranslatedsegmentscheckboxmenuitem": [1],
"discrep": [6],
"probabl": [2],
"relev": [1,[2,3],[6,8]],
"needs-review-transl": [1],
"tagwip": [5,8],
"return": [5,1,8,7],
"nonsens": [1],
"invoke-item": [1],
"usb": [2],
"use": [2,[1,5],3,8,6,7,4,0],
"usd": [5],
"feel": [[2,8],[3,4]],
"main": [5,7,[2,3],[0,8]],
"newlin": [1],
"convent": [8,[0,1]],
"radio": [5],
"omegat.jar": [2,1],
"source-pattern": [2],
"strip": [5,8],
"conveni": [5,[1,2,8]],
"omegat.app": [2,1],
"fine": [1],
"usr": [[1,2,3]],
"find": [1,2,5,8,3,4],
"host": [2,[1,3]],
"logo": [1],
"backward": [6],
"errat": [1],
"credit": [6],
"regardless": [2],
"alter": [5],
"workflow": [8,[2,7],[0,1]],
"utf": [1,4],
"occur": [1],
"autocompletertablepagedown": [1],
"difficult": [2],
"sort": [[1,7],[3,5,6]],
"fill": [4,2,6],
"feed": [1],
"servic": [2,3,7,6],
"forget": [3],
"task": [2,[5,8]],
"cleanup": [5],
"background": [4,[6,7]],
"xliff": [[1,2]],
"true": [1],
"header": [1,[5,6]],
"nonetheless": [1],
"present": [1,2,5,7,[3,6,8]],
"dsl": [4],
"mid-transl": [5],
"belong": [[1,3]],
"groovi": [5],
"pre-defin": [8],
"multi-paradigm": [5],
"best": [7,[3,8],[2,4,5,6]],
"med": [6,1],
"transform": [3],
"fundament": [1],
"execut": [2,1,5],
"hour": [[2,8]],
"dtd": [[1,2]],
"repeat": [[3,5],6,[1,2,7,8]],
"make": [2,1,[4,8],5,3,[6,7],0],
"capit": [2],
"beta": [2],
"abov": [[1,2],[3,5],6,[7,8]],
"sentence-level": [[1,5],[2,8]],
"necessary—to": [2],
"projectcompilemenuitem": [1],
"classnam": [2],
"messageformat": [3,1],
"console-transl": [2],
"stern": [6],
"compound": [3],
"master": [2,3,1],
"optionsautocompletehistorycompletionmenuitem": [1],
"gotonextuniquemenuitem": [1],
"due": [[2,8]],
"conform": [[5,8]],
"underlin": [6,7,3],
"writer": [1],
"wordart": [1],
"merg": [5,8,[1,3]],
"dalloway": [3],
"rubi": [5],
"resource-bundl": [2],
"inform": [7,2,6,[1,3],5,8,4],
"depend": [1,3,[2,6],7,5,8],
"about": [1,[5,8],[2,4,6,7]],
"commit": [2,[1,6]],
"yyyi": [2],
"external_command": [4],
"targetlocalelcid": [1],
"annot": [8],
"project_stats_match.txt": [[4,6]],
"cover": [1,[2,3]],
"editorselectal": [1],
"character": [1],
"tab-separ": [1],
"reflect": [[2,8],[4,6]],
"flexibl": [8],
"runner": [5,1],
"immedi": [1,[5,8],[2,6,7]],
"coordin": [2],
"pointer": [7],
"distinguish": [[6,8]],
"condens": [3],
"omegat-default": [2],
"benefit": [[2,5]],
"user.languag": [2],
"regex": [1,8],
"highest": [7,3],
"meta": [1],
"declar": [1],
"except": [3,1,2,8],
"boost": [1],
"libreoffic": [8,1],
"autocompleterclos": [1],
"qualiti": [6],
"nevertheless": [8],
"scan": [5],
"global": [5,1,3,6,0,[2,7,8]],
"racin": [7],
"long": [1,3],
"into": [2,5,1,6,[3,7],8,4],
"unless": [2,[1,3,8]],
"defin": [1,3,[2,5],7,6,[4,8]],
"industri": [8],
"free": [2,8,[0,1,5]],
"evolut": [1],
"star": [1],
"though": [3],
"disappar": [2],
"thorough": [1,2],
"everyday": [2],
"viewdisplaysegmentsourcecheckboxmenuitem": [1],
"appear": [3,1,5,7,[0,2,8]],
"editregisteremptymenuitem": [1],
"face": [3],
"ibm": [[2,3]],
"stats-output-fil": [2],
"mismatch": [5],
"french—if": [3],
"reliabl": [4,[0,2]],
"progress": [[2,7],3],
"oper": [2,[1,3,5,6],[4,8]],
"mani": [1,2,[7,8]],
"open": [6,[1,5],2,7,[3,8],4],
"treat": [1,[5,7],3],
"parsewis": [5],
"project": [2,5,4,6,1,8,3,7,0],
"seven": [1],
"user-cr": [1],
"trustworthi": [2],
"xmx1024m": [2],
"取得": [[3,5]],
"whatev": [2],
"autotext": [3,1],
"sever": [5,[1,6,7],[2,4,8]],
"loop": [5],
"autocomplet": [1],
"five": [3],
"enclos": [1,6,5,[3,8]],
"penalty-xxx": [[2,4]],
"gotonextsegmentmenuitem": [1],
"invert": [3],
"omegat-cod": [2],
"look": [8,[1,3],2,[0,5,6]],
"repres": [1,3,2],
"dropbox": [2],
"abort": [2],
"left-to-right": [1,6],
"idx": [4],
"internet": [3],
"conflict": [2,[1,8]],
"allow": [[1,5,6],3,8,[2,7]],
"comma-separ": [1],
"squar": [1,3],
"commerci": [8],
"rule": [5,1,3,6,[2,8],[0,4]],
"proper": [2,6,[1,3],[5,7,8]],
"detect": [6,3,2],
"everi": [2,[1,4,6],5,[3,8]],
"speed": [2],
"printf": [1,3],
"peopl": [[2,6]],
"summari": [2],
"outsid": [1,[4,7,8]],
"autocompleterconfirmandclos": [1],
"how-to": [8,4,[1,6],[2,5],[3,7]],
"common": [2,1,7,[5,8]],
"projectaccesscurrentsourcedocumentmenuitem": [1],
"interest": [1],
"appli": [5,3,2,1,[4,6,7]],
"linux": [1,2,6,7,[3,5,8]],
"linux-install.sh": [2],
"again": [8,[2,3,5]],
"file.txt": [2],
"openxliff": [2],
"uncom": [2],
"writabl": [1,6,[2,4,5],7],
"layout": [7,[3,8],1,6,[0,2,5]],
"registri": [1],
"popup": [5],
"format-specif": [3],
"ifo": [4],
"popul": [[3,4,6]],
"comment": [1,7,5,[0,6,8]],
"step": [5,[1,2],8,4],
"bash": [[1,2]],
"basi": [1],
"excit": [1],
"tmroot": [1],
"mark": [[1,5],3,6,7,[4,8]],
"base": [[1,5,8],3,[0,2,6,7]],
"stem": [3,7],
"uncolor": [7],
"registr": [3],
"intermedi": [2],
"disconnect": [2],
"compulsori": [5],
"optionsmtautofetchcheckboxmenuitem": [1],
"xx.docx": [1],
"prefix": [4,3,2],
"whole": [2,[1,3,4,5,6]],
"consist": [1,6,[2,5],[4,7,8]],
"loss": [2],
"大学": [3],
"lost": [[2,6],8],
"editorshortcuts.properti": [1],
"insertcharslr": [1],
"grammat": [[5,6]],
"zip": [3],
"still": [[1,5],[6,7]],
"compress": [[1,4]],
"work": [2,1,[5,8],[3,4,6],0],
"lose": [2,[7,8]],
"suitabl": [[2,7,8]],
"fail": [[2,8],5],
"itself": [1,2,5,[3,4,8]],
"sdlxliff": [2],
"among": [8],
"word": [1,5,[4,6],3,[7,8]],
"variat": [1],
"love": [1],
"lingue": [3],
"langag": [2],
"thumb": [5],
"verifi": [1],
"auto-propag": [[2,5]],
"requir": [2,[1,3],5,8,[6,7],4],
"across": [1,8],
"tmotherlangroot": [1],
"viewmarknotedsegmentscheckboxmenuitem": [1],
"non-vis": [1],
"event": [[1,5],2],
"simplest": [1,2],
"vcs": [2],
"lingvo": [4],
"gotomatchsourceseg": [1],
"appropri": [2,5,[1,8]],
"developer.ibm.com": [2],
"mrs": [3],
"opinion": [7],
"excel": [1],
"comma": [1],
"runn": [5],
"literari": [1],
"cannot": [2,1,7],
"runt": [1],
"averag": [5],
"stardict": [4],
"first": [1,5,7,[2,3,6],8,4],
"omegat.l4j.ini": [2],
"span": [1],
"prefer": [6,1,5,7,2,3,4,8,0],
"quotat": [[1,5]],
"threshold": [3,[2,7]],
"overridden": [2],
"float": [3],
"space": [1,5,[7,8],6,3],
"hard-and-fast": [5],
"ドイツ": [5,3],
"manipul": [[6,7]],
"simpl": [1,3,8,2,5],
"from": [2,5,1,4,7,[3,6],8],
"html": [1,2,[3,8]],
"spell": [3,1,5,6],
"editselectfuzzy3menuitem": [1],
"bottom": [5,3,7,6],
"insertcharsrl": [1],
"templat": [3,1,5],
"fals": [1,[2,3]],
"project.projectfil": [5],
"uncondit": [4],
"finit": [3],
"guidelin": [2],
"frequenc": [2],
"jres": [2],
"www.ibm.com": [3],
"frequent": [1,5,[2,6,8]],
"interact": [[2,5]],
"outright": [6],
"error": [2,7,6,[1,5,8]],
"egregi": [1],
"platform": [2,1,3],
"network": [2],
"shortcut": [1,6,8,5,7,[0,2]],
"public": [2,0],
"briefli": [[1,7]],
"track": [[2,7]],
"tmx2sourc": [2,[1,4]],
"toolsalignfilesmenuitem": [1],
"ini": [2],
"overal": [[1,6]],
"spent": [8],
"instead": [1,[2,3,5,6,8]],
"improv": [1,5],
"command": [5,2,3,1,6,7,[0,8]],
"project-specif": [4,5,[2,3]],
"unlik": [[1,3,8]],
"round": [2],
"dhttp.proxyport": [2],
"detach": [5],
"slash": [1],
"tag-fre": [5,8],
"negat": [1],
"onecloud": [2],
"notat": [1,3],
"viewmarkbidicheckboxmenuitem": [1],
"refus": [[2,8]],
"year": [[1,2]],
"subrip": [2],
"branch": [2],
"via": [2],
"describ": [1,2,7,[5,8]],
"score": [3,5,4],
"fileshortpath": [[1,3]],
"permiss": [5],
"poor": [5],
"double-click": [2,5,3,[1,6,7]],
"visual": [1,[6,8]],
"absent": [2],
"approxim": [5],
"near": [8],
"日本語": [5],
"instruct": [2,1,[4,5]],
"appendix": [5,1,3,6,2,[4,7,8]],
"illustr": [8],
"raw": [2],
"version": [2,[0,1],[4,5,6,8]],
"unassign": [6],
"folder": [2,5,1,4,6,3,8,7,0],
"stop": [[3,5]],
"handl": [1,[2,3],5],
"detail": [2,6,5,1,3,8,4,7],
"retriev": [2],
"projecteditmenuitem": [1],
"least": [[2,5,7]],
"manual": [1,[5,6],2,8,[0,4]],
"dollar": [1],
"new_word": [5],
"recycl": [2],
"run\'n\'gun": [1],
"aspect": [8],
"appendic": [[0,1,4,8]],
"unbeliev": [1],
"measur": [2],
"nashorn": [5],
"machin": [3,6,7,[0,1,5],[2,4,8]],
"close": [1,5,2,6,7,[3,8]],
"unsung": [1],
"descend": [3,1],
"abc": [1],
"learn": [1,8],
"last_entry.properti": [4],
"abl": [2,6,[1,5,8]],
"textual": [5,1],
"toolbar.groovi": [5],
"newer": [6],
"uppercas": [1],
"invok": [5],
"iso": [[1,2]],
"eager": [8],
"isn": [[1,2]],
"optionspreferencesmenuitem": [1],
"thorni": [8],
"autocompleternextview": [1],
"specif": [[1,5],2,3,6,[7,8]],
"red": [[3,4],[1,5]],
"aggreg": [1],
"act": [4,[1,2]],
"soft-return": [1],
"post": [1],
"glossary.txt": [[2,4],[1,6]],
"finish": [5,1],
"dsun.java2d.noddraw": [2],
"placehold": [3,1],
"add": [2,1,5,8,4,7,[3,6]],
"initi": [5,2,[1,4],3],
"multi-word": [1],
"chines": [3],
"ell": [3],
"need": [2,1,8,4,5,3,7],
"equival": [5,3,[1,2],7],
"often": [8,[1,2,5]],
"editorfirstseg": [1],
"x0b": [2],
"gather": [2],
"els": [7],
"respect": [[1,2,4]],
"rfe": [5],
"canada": [2],
"shell": [1],
"port": [2],
"pre-configur": [3],
"altern": [1,6,5,7,3,2,8],
"entry_activ": [5],
"http": [2,3],
"optionsautocompleteshowautomaticallyitem": [1],
"gotoprevxautomenuitem": [1],
"exec": [1],
"trust": [3,5],
"untar": [2],
"interfer": [6],
"lisenc": [1],
"consequ": [[5,8]],
"prevent": [2,[5,6,8],1],
"undo": [[1,6]],
"glitch": [8],
"softwar": [2,1],
"ishan": [1],
"scope": [1,[5,8]],
"pasta": [1],
"untrust": [1],
"projectsinglecompilemenuitem": [1],
"end": [1,5,[2,3,8]],
"lisens": [1],
"footnot": [1],
"modifi": [1,5,2,8,6,3,[4,7],0],
"otherwis": [2,[4,5]],
"myfil": [2],
"particip": [2],
"anyth": [[1,2]],
"label": [7,[3,6]],
"howev": [[1,2,5],8],
"env": [1],
"fledg": [2],
"special": [1,2,[4,5]],
"okapi": [2],
"togeth": [8],
"page_down": [1],
"key-bas": [5],
"numer": [1],
"clone": [2],
"fine-tun": [[1,7]],
"targetlanguag": [[1,3]],
"directori": [1],
"sensit": [1,5],
"backup": [2,4,3,5],
"copyright": [6],
"properti": [2,7,1,8,6,4,[3,5],0],
"project_nam": [5],
"system-os-nam": [1],
"occurr": [5],
"insertcharspdf": [1],
"editselectfuzzyprevmenuitem": [1],
"number": [1,5,7,[2,3],6,4,8],
"identifi": [1,3,[6,8],2,5],
"specifi": [2,1,3,5,7,[4,8]],
"heapwis": [5],
"narrow": [8],
"faulti": [2],
"algorithm": [5,6,1],
"shorter": [5],
"troubleshoot": [[0,2,4,8]],
"invis": [1],
"newli": [[4,5]],
"similar": [[1,2,3],8,[5,7],6],
"tar.bz2": [4],
"paragraph-level": [1],
"forth": [[2,7]],
"bundle.properti": [2],
"script": [5,1,2,6,3,[0,4,8]],
"contributors.txt": [1],
"exit": [[2,5],[1,6]],
"system": [2,1,3,[5,6],[4,8],7],
"driver": [3],
"spellcheck": [3,8,4,5,[0,2],[1,6]],
"www.regular-expressions.info": [1],
"characterist": [[1,3,5]],
"issu": [6,3,2,1,8,[0,4]],
"partial": [2],
"other": [[1,2],5,8,[3,7],4,0,6],
"sourcelang": [1],
"against": [[2,7,8]],
"retain": [[1,2]],
"parenthes": [[1,3]],
"login": [3,1,0],
"cell": [5,1],
"local": [2,5,3,1,6,7,4],
"optionsdictionaryfuzzymatchingcheckboxmenuitem": [1],
"resum": [[1,8]],
"remind": [[1,4,6,8]],
"valid": [1,6,3,[2,4]],
"assur": [6],
"pictur": [8],
"interfac": [2,1,[3,6],[7,8]],
"projet": [7,1],
"locat": [2,1,5,6,[3,8],4,7],
"yield": [5],
"share": [2,5,4,[1,8],7],
"sourcelanguag": [3],
"rle": [1,6],
"gzip": [4],
"helpupdatecheckmenuitem": [1],
"duplic": [[1,2,5,8]],
"repo_for_all_omegat_team_project_sourc": [2],
"notic": [5],
"rlm": [1,6],
"notif": [7],
"esc": [7],
"exampl": [1,[2,5],3,6,[7,8],4],
"nostemscor": [3],
"project_chang": [5],
"round-trip": [2],
"screen": [[1,8]],
"correspond": [5,[1,2],[6,7],[3,4]],
"c-x": [1],
"console-createpseudotranslatetmx": [2],
"mode": [2,5,7,6],
"etc": [3,[1,4,7]],
"fuzzyflag": [3],
"toolsshowstatisticsstandardmenuitem": [1],
"all": [5,2,3,1,6,8,4,7],
"precaut": [2],
"border": [7],
"new": [2,5,[1,8],6,3,4,7,0],
"escap": [1,2],
"read": [5,[1,2],3],
"simplic": [2],
"sequenti": [6],
"below": [1,2,7,4,[3,5,6,8]],
"c.t": [1],
"alt": [1,6],
"poisson": [5],
"runway": [1],
"choos": [[1,2],[3,5]],
"rememb": [2,[6,8],4,[1,5]],
"half-width": [5],
"real": [[2,7]],
"tool": [2,[3,5],[1,4,6],[0,8]],
"morfologik": [3],
"ll-cc.tmx": [2],
"unit": [1,5],
"alreadi": [2,[4,5],[1,3,8],6],
"therefor": [1,5,2],
"collect": [[1,4]],
"two-lett": [2,[5,8]],
"redo": [[1,6]],
"slot": [6],
"around": [[3,7,8],6],
"grunt": [1],
"reload": [6,5,[1,2,4,8]],
"tkit": [2],
"calcul": [[3,7],5],
"and": [1,2,5,[6,8],7,3,4,0],
"synchron": [2,[5,7,8],[3,4,6]],
"predict": [3,[1,8]],
"row": [5,[1,6]],
"ani": [1,2,5,8,4,6,7,[0,3]],
"render": [5],
"magento": [2],
"ll.tmx": [2],
"backs-up": [4],
"ant": [[2,5]],
"korean": [3],
"boundari": [1,8],
"dispar": [2],
"offlin": [2],
"ll_cc.tmx": [2],
"unnecessari": [4,[2,3]],
"u00a": [5],
"helplastchangesmenuitem": [1],
"until": [2,[3,5,8]],
"omegat.ex": [2],
"reason": [1,3,[2,5,6]],
"shift": [1,6,5],
"sourcetext": [3],
"simultan": [[2,3]],
"java": [2,1,3,5,8],
"exe": [2],
"english": [2,[1,3]],
"xmxsize": [2],
"mistak": [5,3,[1,6,8]],
"jar": [2,3],
"api": [[3,5]],
"editselectfuzzy2menuitem": [1],
"project_save.tmx": [2,4,[5,8],6],
"encapsul": [5],
"dictionari": [3,[4,8],7,6,[1,5],0,2],
"remain": [5,4,6,2],
"powershel": [[1,2]],
"eye": [1],
"letter": [1,6,2,[5,8],3],
"grade": [8],
"editornextseg": [1],
"appl": [1],
"editselectfuzzynextmenuitem": [1],
"recommend": [2,[1,5]],
"gotonextxautomenuitem": [1],
"worth": [[5,8]],
"read.m": [1],
"default": [1,[3,5],6,2,7,4,8,0],
"gray": [6,5,8],
"are": [1,5,2,3,6,7,4,8],
"cloud.google.com": [3],
"taken": [3,[4,6],[2,5,7]],
"readme.bak": [2],
"arg": [2],
"came": [4,2],
"where": [1,[2,5],7,6,[3,8],4],
"sudo": [2],
"drop-down": [5,1,3],
"timestamp": [[1,2]],
"logogram": [1],
"broken": [8],
"vice": [5],
"projectaccessrootmenuitem": [1],
"nest": [1],
"fulli": [4],
"call": [1,5,2,6,[3,4,7,8]],
"facilit": [8],
"such": [1,2,5,3,8,[4,7],6],
"plugin": [3,[1,2],[0,8]],
"autocompletertableup": [1],
"essenti": [2],
"ask": [2,[5,6],3,[1,7,8]],
"principl": [0,[7,8]],
"understood": [5],
"through": [2,[5,7],[1,3,6,8]],
"toolsshowstatisticsmatchesperfilemenuitem": [1],
"strength": [5],
"projectcommitsourcefil": [1],
"editinsertsourcemenuitem": [1],
"run": [5,[1,2],3,6,0,[7,8]],
"viterbi": [5],
"microsoft": [1,[5,8]],
"reorgan": [1],
"projectnewmenuitem": [1],
"ecmascript": [5],
"worri": [8],
"view": [7,3,1,8,[0,5,6],4],
"either": [1,2,[4,5,8],3,6],
"lowercas": [1],
"white": [1,6],
"editorshortcuts.mac.properti": [1],
"segment": [5,6,1,7,3,8,4,2,0],
"changes.txt": [[1,2]],
"titlecasemenuitem": [1],
"yourself": [8],
"those": [2,[1,5,8],4,[3,7]],
"glossari": [1,7,5,6,4,[3,8],2,0],
"recurs": [5],
"editcreateglossaryentrymenuitem": [1],
"ignored_words.txt": [4],
"might": [2,8,1],
"github.com": [2],
"configuration.properti": [2],
"ital": [[1,5,8]],
"bold": [3,[5,7],1,8],
"autocompleterlistpageup": [1],
"dure": [[2,5,8],4],
"effici": [8],
"longer": [3,[1,2,7],5],
"introduc": [[5,6]],
"supersed": [5],
"多和田葉子": [5],
"occupi": [5],
"reopen": [2],
"name": [1,2,[3,8],7,5,4],
"physic": [2],
"recreat": [[1,2,4,8]],
"notabl": [[2,7]],
"next": [1,6,5,2,8,7,3,[0,4]],
"string": [5,1,6,3,2,8],
"import": [[1,2],[4,7,8]],
"hidden": [4,[5,7]],
"reli": [1,2,6],
"book": [[1,4,8]],
"show": [5,7,2,3,1,[4,8]],
"cautious": [2],
"target-languag": [2],
"non": [1],
"button": [5,8,1,3,6],
"nor": [[1,3]],
"comput": [2,[0,3,8]],
"not": [1,2,5,3,8,6,4,7],
"introduct": [0,[2,8]],
"now": [[1,2],8],
"trademark": [7],
"factor": [6],
"editortogglecursorlock": [1],
"enabl": [3,[1,7],6,2,5,[4,8]],
"greek": [1],
"green": [5,7,6],
"associ": [1,2,[3,6],8,[5,7]],
"pseudotransl": [2],
"was": [3,[1,2],5,[4,8]],
"subfold": [2,[1,5],4,6],
"greet": [8],
"new_fil": [5],
"viewrestoreguimenuitem": [1],
"selection.txt": [[1,6]],
"way": [1,2,8,[5,6],0],
"target": [1,6,5,[2,3],8,4,7,0],
"xhtml": [1],
"what": [1,[2,5,8],3],
"knowledg": [2],
"itoken": [2],
"finder.xml": [[1,4,5]],
"refer": [1,2,5,4,8,6,7],
"workfow": [8],
"colon": [1],
"window": [5,1,6,7,2,3,8,[0,4]],
"call-out": [6],
"config-dir": [2],
"editorskipprevtokenwithselect": [1],
"discard": [5],
"any—wil": [3],
"criteria": [5,[1,8]],
"disable-project-lock": [2],
"omegat.pref": [[1,3,5]],
"when": [5,2,3,1,7,8,[4,6]],
"termbas": [1],
"sequenc": [1,8],
"auto-popul": [4,6,3,2,1],
"txml": [2],
"carriage-return": [1],
"far": [7,2],
"embed": [1,6],
"case": [1,6,2,5,3,[4,7,8]],
"give": [6,2,1,[0,3,4,5,8]],
"item": [6,1,5,8,3,7],
"multipl": [2,1,7,3,[0,5,8]],
"violet": [6],
"modul": [3,6],
"unfriend": [6],
"matcher": [1],
"lowest": [7],
"explicit": [2],
"targettext": [3],
"studi": [0],
"consid": [1,[3,4],[2,6,8]],
"slide": [1],
"reset": [5,1,3],
"everyth": [[1,2]],
"style": [[2,5]],
"explor": [1],
"suit": [1,[2,7,8]],
"card": [5,1],
"care": [8],
"widget": [7],
"orang": [[1,5,7]],
"portion": [1,5],
"guard": [2],
"direct": [[1,2],6,[0,4,5,7]],
"pattern": [1,3,5,2],
"compil": [5],
"caus": [[1,6]],
"freedom": [0],
"mechan": [2,[1,6]],
"modern": [2],
"web": [3,5,2,[1,6,7]],
"edittagpaintermenuitem": [1],
"en-us_de_project": [2],
"temporarili": [[3,7]],
"you\'r": [8],
"symlink": [2],
"older": [2],
"protect": [3,8],
"nth": [5],
"editselectfuzzy4menuitem": [1],
"editregisteridenticalmenuitem": [1],
"more": [1,5,[2,8],[3,4],7,6],
"display": [3,5,6,[1,7],8,[2,4]],
"hanja": [1],
"great": [8],
"unicod": [1,6],
"viewmarknbspcheckboxmenuitem": [1],
"fanci": [1],
"projectmedcreatemenuitem": [1],
"usag": [[2,5]],
"computer-assist": [[0,8]],
"left-hand": [5],
"certain": [2,7,[1,6]],
"advanc": [5,1,6,3],
"shut": [5],
"overwrit": [7,[4,6],[1,2]],
"path-to-omegat-project-fil": [2],
"fed": [2],
"whitespac": [1,[2,6]],
"credenti": [3,2,7],
"section": [2,8,1,5,3,[6,7]],
"auto-complet": [3,1,[7,8],6,0],
"simpli": [1,5,[2,8],4],
"cloud": [2],
"protocol": [2,3],
"msgstr": [1],
"few": [1,[6,8],2,5],
"dict": [3],
"untransl": [1,5,6,[3,7],[2,8],4],
"nationalité": [3],
"kind": [1,3],
"daili": [1],
"resiz": [7],
"autopopul": [1],
"both": [5,1,2,3,7],
"most": [1,2,6,[5,7],[0,3,4]],
"delimit": [3,7,[5,6],1],
"phrase": [1,5,8],
"omegat.project": [2,4,8,[3,5,7]],
"button-bas": [6],
"marker": [[1,3,7],2],
"keep": [5,2,1,4,[3,7,8]],
"effect": [1,5,3],
"whi": [1],
"topic": [[1,2]],
"excludedfold": [2],
"targetcountrycod": [1],
"job": [8,2],
"fallback": [[1,6]],
"option": [2,1,5,3,6,8,4,7,0],
"who": [3,[2,5],6],
"overtyp": [1],
"continu": [8,[1,2,5]],
"insert": [1,6,3,4,7,2,5,8],
"remark": [8],
"everyon": [2],
"resid": [2],
"highlight": [5,6,1,7,[3,4]],
"along": [1,5],
"reject": [3],
"arrang": [3],
"sheet": [1],
"messag": [7,[1,2]],
"rest": [1,[2,8]],
"move": [6,5,7,8,[1,3]],
"amount": [2],
"also": [2,5,1,3,8,4,[6,7]],
"enough": [2],
"differ": [3,2,5,6,1,[7,8]],
"conson": [1],
"situat": [[1,2]],
"consol": [2],
"mous": [5,[6,7,8]],
"various": [8,1,6,5,[2,7],3,4],
"archiv": [3,4],
"front": [2],
"visit": [6,4],
"user": [2,1,3,6,8,[0,5,7]],
"itokenizertarget": [2],
"viewmarkwhitespacecheckboxmenuitem": [1],
"proxi": [2,3,0],
"extens": [1,2,3,4,[5,6,7]],
"back_spac": [1],
"potenti": [1,[3,4,6]],
"asterisk": [1],
"bring": [5,[1,2,7]],
"tooltip": [3,7],
"complet": [1,3,2,5],
"recalcul": [5],
"avoir": [1],
"bak": [2,4],
"canon": [1],
"offer": [2,[1,8],7,[3,5]],
"robot": [1],
"fit": [[7,8]],
"bar": [7,1,[0,8]],
"claus": [1],
"fix": [2,[1,4,6]],
"built-in": [3],
"complex": [1,[2,5]],
"jre": [2],
"rang": [1,2],
"despit": [5],
"posit": [1,6,[5,7],3],
"eclips": [2],
"sure": [2,3,5,[1,7,8]],
"ad": [[1,2,5],3,[4,6,8]],
"reus": [2,[6,8],[1,3,5]],
"diff": [3],
"automat": [5,[2,3],[4,6],8,1,7],
"secur": [3,5,[0,1]],
"an": [1,2,[5,8],3,6,7,4],
"editmultiplealtern": [1],
"panic": [8],
"extend": [[2,5]],
"as": [1,2,5,3,6,[4,7],8,0],
"day-to-day": [1],
"at": [5,1,[2,3,7],8,6,4],
"predefin": [3,[1,2]],
"constitut": [1,[2,4]],
"hierarchi": [4,2],
"ordinarili": [1],
"drive": [2],
"file-shar": [2],
"alllemand": [5],
"non-gui": [2],
"deal": [[1,5]],
"strong": [1],
"be": [1,2,5,3,6,4,8,7],
"affect": [2],
"icon": [6,7],
"filters.xml": [1,[2,3,4,5]],
"delet": [2,1,[3,6,8],[4,5]],
"proven": [1],
"version-control": [2],
"bcp": [[5,8]],
"br": [1],
"projectaccessglossarymenuitem": [1],
"javadoc": [5],
"search": [5,1,3,6,8,7,0,[2,4]],
"see": [2,6,5,1,8,3,4,7],
"by": [1,2,5,3,4,6,8,7,0],
"segmentation.conf": [[1,2,4,5]],
"panel": [5,3],
"ca": [2],
"cc": [2],
"ce": [2],
"set": [2,3,5,1,[4,6],8,7,0],
"contain": [1,4,2,5,7,3,8,6],
"incorrect": [[4,5]],
"balis": [7],
"fastest": [0],
"column": [5,[1,6],3],
"freeli": [[1,7]],
"figur": [7,8],
"cs": [1],
"renam": [2,8,[1,3]],
"instantan": [2],
"partner": [2],
"somewhat": [8],
"apach": [2,5],
"config": [2],
"adjustedscor": [3],
"font": [3,6,7,[1,8]],
"dd": [2],
"de": [[3,7]],
"featur": [[3,5],[2,7,8]],
"offic": [[1,2],[5,8]],
"terminolog": [1,6],
"repositories.properti": [[1,2]],
"extern": [5,3,6,1,[7,8],[0,2,4]],
"forc": [1,[3,5,6]],
"do": [1,2,[3,5],[6,8],7,4],
"f1": [[1,5,6]],
"f2": [[7,8],[1,5]],
"f3": [[1,6],7],
"parti": [[2,3,7]],
"f5": [[1,6,8]],
"dz": [4],
"projectsavemenuitem": [1],
"editundomenuitem": [1],
"rare": [2],
"won": [2],
"contact": [7],
"xmx6g": [2],
"autocompletertablefirstinrow": [1],
"digit": [1,[2,5]],
"which": [1,5,2,6,[7,8],3],
"signific": [1],
"belazar": [3],
"en": [1],
"carri": [[5,6]],
"eu": [6],
"never": [1,[4,6,8]],
"tmautoroot": [1],
"aggress": [[1,6]],
"adjust": [5,[2,4]],
"activ": [6,3,1,5,[2,4,7]],
"first-class": [5],
"compat": [1,2,[3,5]],
"compar": [5,8],
"cursor": [7,6,8,3,1,5],
"prototype-bas": [5],
"indic": [7,1,6,[2,3]],
"insertcharslrm": [1],
"origin": [2,1,5,[7,8],3],
"for": [[1,2],5,3,6,8,4,7,0],
"exclud": [2,5,[1,6]],
"fr": [2,[3,8]],
"content": [1,2,5,8,3,4,6,[0,7]],
"duckduckgo": [3],
"random": [1],
"hover": [[3,6,7]],
"desktop": [2],
"decor": [8,[1,5]],
"applescript": [2],
"skill": [2],
"client": [2,[1,4]],
"json": [2],
"exclus": [5,2],
"gb": [2],
"class": [1],
"helplogmenuitem": [1],
"over": [6,2,[3,4,7]],
"six": [8],
"someth": [[2,3]],
"easy-to-us": [8],
"editoverwritetranslationmenuitem": [1],
"bound": [5],
"go": [1,7,8,[2,6],4,[0,3,5]],
"counter": [5],
"kept": [4,[1,5]],
"aeiou": [1],
"form": [1,5,2],
"publish": [2],
"setup": [2],
"restor": [[2,3,7],[1,4,6],5],
"avoid": [[1,2],[5,8]],
"foundat": [2],
"targetroot": [1],
"prompt": [2],
"subset": [[1,2]],
"assign": [1,[5,6],[2,4,8],[3,7]],
"typograph": [[5,6]],
"hh": [2],
"select": [6,5,1,7,3,2,8,4],
"duser.languag": [2],
"viewmarkparagraphstartcheckboxmenuitem": [1],
"bin": [1,[2,3]],
"canadian": [3],
"degre": [1],
"easili": [8,4],
"apertium": [3],
"bit": [6],
"bis": [1],
"kaptain": [2],
"meta-inf": [2],
"clipboard": [6],
"repetit": [[5,6,7],1],
"output": [2,[0,3]],
"veri": [8,5,[1,3,6],2],
"file-target-encod": [1],
"projectopenmenuitem": [1],
"autom": [2,[3,5,8]],
"corner": [7],
"four": [1,[2,6]],
"decim": [1],
"mainmenushortcuts.mac.properti": [1],
"context": [3,7,6,[1,2,4,8]],
"ordinari": [1],
"model": [[3,5]],
"id": [3,1,5],
"https": [2,3,1,[4,7]],
"drag": [7,2],
"join": [8],
"decis": [4],
"if": [2,5,6,1,3,7,8,4],
"french": [[2,3],5],
"project_stats.txt": [4,6],
"non-ascii": [1],
"ocr": [5],
"oct": [3],
"projectaccesscurrenttargetdocumentmenuitem": [1],
"in": [1,5,2,6,3,7,8,4,0],
"lower": [1,6,[4,5,7]],
"termin": [2],
"ip": [2],
"index": [1],
"is": [1,2,5,7,3,6,4,8,0],
"it": [1,2,5,4,7,3,8,6,0],
"vertic": [1],
"decid": [8,[1,2]],
"projectaccesstmmenuitem": [1],
"odf": [1],
"smoother": [[5,8]],
"contrast": [1],
"ja": [[2,3]],
"becam": [2],
"begin": [1,8],
"odt": [[1,5]],
"gotonexttranslatedmenuitem": [1],
"viewmarktranslatedsegmentscheckboxmenuitem": [1],
"paragraph": [1,5,3,7,[2,6],8],
"charset": [1],
"viewer": [7],
"valu": [1,5,[2,3],6],
"librari": [1],
"standalon": [3],
"ilia": [2],
"toolscheckissuescurrentfilemenuitem": [1],
"libraries.txt": [1],
"learned_words.txt": [4],
"language—th": [1],
"world": [2],
"meantim": [2],
"uxxxx": [1],
"ftl": [[1,2]],
"reappli": [6],
"side": [[2,7],[1,5]],
"break": [1,3,[5,8]],
"editselectfuzzy1menuitem": [1],
"themselv": [1,2,3],
"upgrad": [[2,3],5],
"viewdisplaymodificationinfoallradiobuttonmenuitem": [1],
"tabular": [3],
"draw": [1],
"characters—known": [1],
"non-default": [2],
"comfort": [[2,5]],
"off": [[5,6,8]],
"hide": [5,7,1,[3,6,8]],
"extran": [[1,3,5]],
"la": [3],
"report": [2,[1,5,6,8]],
"li": [1],
"autocompleterlistpagedown": [1],
"ll": [2],
"auto": [[1,6],4,2,[3,5]],
"receiv": [[3,7]],
"notepad": [7,8,6,[0,1]],
"sign": [1,7],
"document.xx.docx": [1],
"lu": [1],
"editorskipnexttokenwithselect": [1],
"while": [6,1,[7,8],5,[2,3]],
"ja-jp.tmx": [2],
"second": [[3,6],[1,2,5,7]],
"that": [1,2,5,3,8,4,6,7],
"cycleswitchcasemenuitem": [1],
"download": [2,3,[1,8],[4,5,6]],
"split": [5,1,8,[3,6,7]],
"mb": [2],
"oracl": [1],
"editortoggleovertyp": [1],
"than": [3,1,2,[4,5],8,[6,7]],
"limit": [1,2,[3,4,8]],
"me": [[2,7]],
"non-translat": [1],
"picker": [2],
"mm": [2],
"gradlew": [2],
"entri": [5,6,[1,3,7],8,2,4],
"level": [5,8],
"ms": [1],
"author": [5,[6,8]],
"toggl": [[1,7],5],
"mt": [4],
"modif": [1,3,6,[2,7],[5,8],4],
"my": [[1,2]],
"cascad": [3],
"plus": [1],
"establish": [2],
"expand": [1],
"disk": [5,2,3],
"legaci": [1],
"viewmarklanguagecheckercheckboxmenuitem": [1],
"unseg": [8],
"updat": [[2,3,4],5,[0,1,6,8]],
"ubiquit": [6],
"produc": [2,1,[5,7]],
"three-lett": [[5,8]],
"licenss": [1],
"no": [1,5,2,3,6,[7,8],4],
"code": [1,5,[2,8],3],
"bridg": [2,[1,4]],
"underscor": [1],
"gotohistoryforwardmenuitem": [1],
"box": [5,1,3],
"switch": [5,1,6,[2,3,8]],
"head": [1],
"dialog": [3,[5,8],[1,2,6],[0,4]],
"project_save.tmx.timestamp.bak": [4],
"immut": [4],
"total": [7,[5,6]],
"of": [1,2,5,3,8,6,7,4,0],
"bundl": [[2,3],1],
"possibl": [2,1,3,[0,7]],
"involv": [2,5,4],
"ok": [5,6,8],
"dynam": [5],
"hear": [1],
"on": [2,1,5,[3,7],6,8,4],
"keyboard": [1,[6,7]],
"macro": [5],
"purpos": [[1,2],0,[3,5]],
"technic": [1,2],
"or": [1,5,2,6,7,8,3,4],
"os": [6,1,7],
"src": [2],
"gigabyt": [2],
"control": [1,6,2,8],
"encod": [1,[4,5]],
"no-team": [2],
"editinserttranslationmenuitem": [1],
"extrem": [1,[2,8]],
"lissens": [1],
"fileextens": [1],
"offici": [[0,1]],
"easier": [[1,2,8],6],
"compliant": [2],
"passphras": [2],
"pm": [[3,7]],
"po": [[1,2],3,[4,7]],
"closest": [3],
"upper": [6,1],
"ssh": [2],
"environ": [2,1],
"qa": [5,6],
"autocompletertablefirst": [1],
"specialti": [2],
"necessari": [2,[1,3,5,8]],
"vari": [7,[1,2]],
"friend": [1],
"concurr": [6],
"recent": [[2,6],[1,5,7]],
"they": [1,5,2,[7,8],[3,4],6],
"pinpoint": [5,2],
"streamlin": [8],
"github": [2],
"edit": [5,7,1,8,2,[3,6],0],
"old": [2,[3,5]],
"subtract": [4],
"editselectfuzzy5menuitem": [1],
"them": [1,[2,8],5,6,[4,7],3],
"bilingu": [2,[4,5]],
"then": [2,8,1,[5,7],[3,4,6]],
"kde": [2],
"accept": [5,[2,3],4],
"third-parti": [2,8],
"rc": [2],
"includ": [2,1,5,4,[3,6,7,8]],
"readili": [2],
"single-click": [3],
"adopt": [1],
"t0": [8],
"t1": [8],
"t2": [8],
"t3": [8],
"minut": [2,[3,4,6,8]],
"access": [1,5,[2,6],8,3,4,0],
"currenc": [[1,5]],
"languag": [2,[3,5],1,8,4,6,7],
"seen": [1],
"sa": [3],
"seem": [2],
"sc": [1],
"current": [6,5,1,[2,7],3,4,8],
"sl": [2],
"optionsglossaryfuzzymatchingcheckboxmenuitem": [1],
"so": [2,1,[5,8],7,[0,4,6]],
"caution": [2,[1,5]],
"email": [1],
"key": [1,5,6,[3,7],[2,8]],
"apart": [5],
"communic": [7],
"intern": [2,6,[1,3,7]],
"starter": [1],
"onc": [2,5,8,6,[1,3]],
"one": [1,5,6,2,7,8,3,4],
"anymor": [2],
"msgid": [1],
"launch": [2,5,3,1,6,8],
"svn": [2,5,4],
"store": [1,2,5,8,3,[4,7],6,0],
"interv": [3,2,[4,6]],
"omegat-license.txt": [1],
"editoverwritesourcemenuitem": [1],
"stori": [1],
"closer": [3],
"confirm": [[1,3,4,5,6],2],
"omegat.autotext": [1],
"emerg": [2],
"kilobyt": [2],
"enforc": [4,6,[1,2],[3,8]],
"th": [6],
"problemat": [8],
"bug": [[1,6]],
"remov": [5,1,2,4,3,6],
"tl": [2],
"tm": [4,2,6,[1,5],3,[0,7],8],
"assist": [[7,8]],
"to": [2,1,5,8,3,6,7,4,0],
"v2": [2,3],
"typic": [1,[2,3]],
"editreplaceinprojectmenuitem": [1],
"but": [1,2,5,8,[3,4],6,7],
"document.xx": [1],
"symbol": [1,7,[2,5]],
"editordeletenexttoken": [1],
"express": [1,5,3,2,8,0],
"multilingu": [1],
"viewmarkautopopulatedcheckboxmenuitem": [1],
"zero": [1,5],
"projectwikiimportmenuitem": [1],
"deactiv": [6],
"countri": [2],
"drawback": [2],
"variant": [[1,2]],
"subsequ": [[1,3]],
"un": [2],
"up": [1,2,5,[4,8],3,7,6,0],
"written": [[1,2,5,6]],
"us": [1],
"gotoprevioussegmentmenuitem": [1],
"partway": [[2,5]],
"newword": [5],
"usual": [[2,6]],
"this": [5,1,2,[3,6],4,7,8,0],
"gotopreviousnotemenuitem": [1],
"stderr": [1],
"editredomenuitem": [1],
"uilayout.xml": [[1,4]],
"verif": [3],
"substitut": [6],
"opt": [2,1],
"extract": [5,[1,3,4]],
"sourceroot": [1],
"hint": [8],
"know": [1],
"projectʼ": [8],
"region": [1,[2,3]],
"support": [2,5,[1,8],4,[3,6],0],
"vs": [3],
"sinc": [2,[1,8],5],
"higher": [3,1],
"changed": [3],
"drop": [7,[2,4]],
"idea": [[2,5]],
"we": [1,8],
"unchang": [8],
"rearrang": [[6,7]],
"wavy-lin": [3],
"autocompleterlistup": [1],
"licenc": [1],
"omegat.project.bak": [2,4],
"repo_for_omegat_team_project": [2],
"choic": [5,[1,2]],
"normal": [[1,5],2,[3,4]],
"gradual": [[1,2,4]],
"slight": [[1,7]],
"corrupt": [2],
"previous": [1,6,8,7,2,[4,5]],
"projectaccessexporttmmenuitem": [1],
"wide": [2],
"licens": [2,1,0,[3,6]],
"org": [2],
"distribut": [5,2,1,0,3],
"behav": [2,1],
"daunt": [1],
"punctuat": [1],
"example.email.org": [1],
"xx": [1],
"runtim": [2,1],
"sourc": [[1,2],5,6,3,7,4,8,0],
"individu": [1,5,[2,6]],
"reach": [8,2],
"realiz": [8],
"ressourc": [0],
"none": [3,5,[1,4,6]],
"type": [2,5,1,[3,7],8,[4,6]],
"beyond": [[1,8]],
"april": [1],
"problem": [[2,7],6],
"review": [8,[2,5],[0,1,4,7]],
"filenam": [1,5,[2,3,7]],
"optionsautocompletehistorypredictionmenuitem": [1],
"projectaccesssourcemenuitem": [1],
"roam": [1],
"between": [[2,7],1,6,[3,5],8],
"yy": [1],
"nbsp": [5],
"method": [2,[5,7]],
"contract": [1],
"gotosegmentmenuitem": [1],
"scroll": [[3,7,8]],
"come": [[1,2],8,4,[5,7]],
"push": [2],
"exist": [2,[5,6,7,8],1,[3,4]],
"readme_tr.txt": [2],
"hunspel": [3],
"penalti": [4,3],
"exact": [5,1,[2,6],[4,8]],
"regist": [2,3,[1,6,7],[5,8]],
"initialcreationd": [3],
"references—in": [1],
"flag": [3,6,1,[7,8]],
"spacebar": [1],
"utf8": [1,[5,6]],
"helpaboutmenuitem": [1],
"copi": [2,5,[3,6,7],1,4,[0,8]],
"out": [5,[1,6],[2,7,8]],
"weak": [1,5],
"get": [2,[1,5,8]],
"dark": [3],
"statist": [6,[2,4],5,3,1],
"power": [1,5],
"place": [1,[2,5],[4,6],3],
"packag": [2,6],
"accur": [[4,5]],
"leav": [3,[6,8],7,[1,4],2],
"regular": [1,5,2,3,4,[0,7,8]],
"context_menu": [1],
"editsearchdictionarymenuitem": [1],
"restart": [2,1,6,3],
"tag-valid": [2],
"ovr": [7],
"suggest": [7,3,1],
"alway": [[1,2],[3,4],6,[5,8]],
"lead": [1],
"token": [1,2,3,5,[4,7]],
"filter": [1,2,5,3,6,8,0,4],
"readabl": [3],
"help": [1,[2,8],[0,6],5],
"expect": [[1,2],3],
"site": [1,2,3],
"projectroot": [1],
"right-to-left": [1,6],
"omegat.log": [1],
"behaviour": [2,6],
"carriag": [1],
"revis": [8],
"repositori": [2,4,[5,6,7],[0,1,3]],
"minimum": [4,[1,3]],
"autocompletertableright": [1],
"date": [3,[1,5,8],4],
"magic": [1],
"argument": [1],
"data": [2,3,6,5,4,[7,8]],
"lowercasemenuitem": [1],
"own": [[1,2],5,7],
"wiki": [[2,3,4]],
"autocompleterconfirmwithoutclos": [1],
"separ": [1,2,5,3,7,8,[4,6]],
"tab": [1,[6,7],3],
"filepath": [3,1],
"plain": [[1,5]],
"should": [1,3,2,5,[4,6,8]],
"tag": [3,1,8,6,5,2,7,0],
"replac": [5,1,6,3,2,8,7,[0,4]],
"ja-jp": [2],
"versa": [5],
"tap": [8],
"like": [2,[1,5,8],4,7],
"maxim": [7],
"onli": [1,5,2,3,[6,8],7],
"brace": [1],
"sent": [3],
"projectreloadmenuitem": [1],
"core": [4],
"person": [5,2],
"safe": [2],
"navig": [8,[4,6,7],2],
"send": [2,3],
"here": [3,[1,7],2,5,4,[6,8]],
"note": [2,1,6,5,7,3,8,4],
"week": [2],
"cross-platform": [2],
"line": [1,2,5,[3,7],4],
"noth": [[6,8]],
"link": [[1,8],3,[4,7]],
"hero": [1],
"provis": [2],
"becom": [[2,4,8]],
"tbx": [1,3],
"wildcard": [2],
"can": [2,1,5,8,3,7,6,4,0],
"everybodi": [2],
"contributor": [[1,5]],
"git": [2,4],
"satisfi": [[2,5]],
"cat": [[1,5,8]],
"duser.countri": [2],
"provid": [2,3,1,5,7,[6,8]],
"realli": [6],
"xx-yy": [1],
"smooth": [8],
"reboot": [2],
"readm": [1,3],
"will": [2,1,3,5,4,8,[6,7]],
"readi": [2],
"self-host": [2],
"match": [1,3,6,5,7,4,2,8,0],
"follow": [1,2,5,6,[7,8],3,[0,4]],
"categori": [1],
"intent": [1],
"fragment": [[1,8]],
"targetlang": [1],
"align.tmx": [2],
"file2": [2],
"arbitrari": [2],
"optionssetupfilefiltersmenuitem": [1],
"wild": [5,1],
"intend": [1,[2,4]]
};
